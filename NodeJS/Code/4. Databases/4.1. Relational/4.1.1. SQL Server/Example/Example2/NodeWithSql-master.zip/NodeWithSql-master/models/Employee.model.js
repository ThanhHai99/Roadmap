var TYPES = require('tedious').TYPES;
const Employee = {
    title: TYPES.VarChar,
    description: TYPES.VarChar
}
